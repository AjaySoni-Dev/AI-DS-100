# Project Description: Credit Card Customer Segmentation Basic

## Level
Basic

## Project Type
Clustering / Segmentation

## Task Kind
clustering

## Dataset
The project uses synthetic dataset file(s): `dataset.csv`. The data is generated for learning purposes but follows practical feature-target relationships so the notebook can be executed end-to-end.

## Target / Main Output
`segment`

## Implementation Details
The Jupyter Notebook is fully executed and contains visible outputs. It includes dataset loading, data inspection, exploratory analysis, charts, preprocessing, modeling or analytics logic, metric calculation, and artifact saving.

## Charts Present in the Notebook
1. `charts/01_elbow_chart.png`
2. `charts/02_pca_clusters.png`

## Metrics / Output Summary
- Silhouette: 0.3862

## Generated Artifacts
- Executed notebook with output cells
- Chart PNG files inside `charts/`
- Project summary JSON
- PDF report
- Any task-specific output CSV files, when applicable

## Note
This project is designed as a clean portfolio-ready educational project. The dataset is synthetic and should not be used for real medical, financial, legal, or production decision-making.
