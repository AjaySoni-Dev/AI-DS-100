# Project Description: Calories Burned Prediction

## Level
Basic

## Project Type
Regression

## Task Kind
regression

## Dataset
The project uses synthetic dataset file(s): `dataset.csv`. The data is generated for learning purposes but follows practical feature-target relationships so the notebook can be executed end-to-end.

## Target / Main Output
`calories_burned`

## Implementation Details
The Jupyter Notebook is fully executed and contains visible outputs. It includes dataset loading, data inspection, exploratory analysis, charts, preprocessing, modeling or analytics logic, metric calculation, and artifact saving.

## Charts Present in the Notebook
1. `charts/01_target_distribution.png`
2. `charts/02_feature_distribution.png`
3. `charts/03_correlation_heatmap.png`
4. `charts/04_actual_vs_predicted.png`
5. `charts/05_feature_importance.png`

## Metrics / Output Summary
- MAE: 100.7659
- RMSE: 124.2744
- R2: 0.3615

## Generated Artifacts
- Executed notebook with output cells
- Chart PNG files inside `charts/`
- Project summary JSON
- PDF report
- Any task-specific output CSV files, when applicable

## Note
This project is designed as a clean portfolio-ready educational project. The dataset is synthetic and should not be used for real medical, financial, legal, or production decision-making.
