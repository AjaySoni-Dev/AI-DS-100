# Project Description: Resume Screening System

## Level
Intermediate

## Project Type
NLP Classification

## Task Kind
nlp_classification

## Dataset
The project uses synthetic dataset file(s): `text_dataset.csv`. The data is generated for learning purposes but follows practical feature-target relationships so the notebook can be executed end-to-end.

## Target / Main Output
`category`

## Implementation Details
The Jupyter Notebook is fully executed and contains visible outputs. It includes dataset loading, data inspection, exploratory analysis, charts, preprocessing, modeling or analytics logic, metric calculation, and artifact saving.

## Charts Present in the Notebook
1. `charts/01_text_length_distribution.png`
2. `charts/02_label_distribution.png`
3. `charts/03_confusion_matrix.png`
4. `charts/04_top_text_features.png`

## Metrics / Output Summary
- Accuracy: 1.0000
- Precision_weighted: 1.0000
- Recall_weighted: 1.0000
- F1_weighted: 1.0000

## Generated Artifacts
- Executed notebook with output cells
- Chart PNG files inside `charts/`
- Project summary JSON
- PDF report
- Any task-specific output CSV files, when applicable

## Note
This project is designed as a clean portfolio-ready educational project. The dataset is synthetic and should not be used for real medical, financial, legal, or production decision-making.
