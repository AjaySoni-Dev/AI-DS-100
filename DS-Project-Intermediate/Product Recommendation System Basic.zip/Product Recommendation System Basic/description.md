# Project Description: Product Recommendation System Basic

## Level
Intermediate

## Project Type
Recommendation System

## Task Kind
recommendation

## Dataset
The project uses synthetic dataset file(s): `users.csv; products.csv; ratings.csv`. The data is generated for learning purposes but follows practical feature-target relationships so the notebook can be executed end-to-end.

## Target / Main Output
`rating`

## Implementation Details
The Jupyter Notebook is fully executed and contains visible outputs. It includes dataset loading, data inspection, exploratory analysis, charts, preprocessing, modeling or analytics logic, metric calculation, and artifact saving.

## Charts Present in the Notebook
1. `charts/01_rating_distribution.png`
2. `charts/02_top_items_by_rating.png`

## Metrics / Output Summary
- MAE: 0.8820
- RMSE: 1.0753
- Users: 90.0000
- Items: 70.0000
- Ratings: 569.0000

## Generated Artifacts
- Executed notebook with output cells
- Chart PNG files inside `charts/`
- Project summary JSON
- PDF report
- Any task-specific output CSV files, when applicable

## Note
This project is designed as a clean portfolio-ready educational project. The dataset is synthetic and should not be used for real medical, financial, legal, or production decision-making.
