# Project Description: Job Recommendation System

## Level
Advanced

## Project Type
Job Recommendation

## Task Kind
job_recommendation

## Dataset
The project uses synthetic dataset file(s): `jobs.csv; candidates.csv`. The data is generated for learning purposes but follows practical feature-target relationships so the notebook can be executed end-to-end.

## Target / Main Output
`match_score`

## Implementation Details
The Jupyter Notebook is fully executed and contains visible outputs. It includes dataset loading, data inspection, exploratory analysis, charts, preprocessing, modeling or analytics logic, metric calculation, and artifact saving.

## Charts Present in the Notebook
1. `charts/01_top_job_matches.png`
2. `charts/02_match_score_distribution.png`

## Metrics / Output Summary
- Average_match_score: 29.0153
- Best_match_score: 94.2343
- Total_recommendations: 1440.0000

## Generated Artifacts
- Executed notebook with output cells
- Chart PNG files inside `charts/`
- Project summary JSON
- PDF report
- Any task-specific output CSV files, when applicable

## Note
This project is designed as a clean portfolio-ready educational project. The dataset is synthetic and should not be used for real medical, financial, legal, or production decision-making.
