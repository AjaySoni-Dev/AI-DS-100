"""Simple Streamlit app for End-to-End ML Model Deployment Project.
Run with: streamlit run app.py
"""
from pathlib import Path
import json
import joblib
import pandas as pd
import streamlit as st

st.title("End-to-End ML Model Deployment Project")
st.write("Upload a CSV file with the same feature columns used in the notebook to generate predictions.")
model_path = Path("trained_model.joblib")
if not model_path.exists():
    st.error("trained_model.joblib not found. Run the notebook first.")
else:
    model = joblib.load(model_path)
    uploaded = st.file_uploader("Upload CSV", type=["csv"])
    if uploaded is not None:
        df = pd.read_csv(uploaded)
        if "will_buy" in df.columns:
            df = df.drop(columns=["will_buy"])
        preds = model.predict(df)
        result = df.copy()
        result["prediction"] = preds
        st.dataframe(result.head(50))
        st.download_button("Download predictions", result.to_csv(index=False), "predictions.csv", "text/csv")
